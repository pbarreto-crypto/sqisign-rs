//! Dimension-4 theta-model arithmetic for SQIsignHD verification.
//!
//! This is the foundational arithmetic layer of the dimension-4 SQIsignHD
//! verifier: theta points (16 𝔽p² coordinates), theta structures (an abelian
//! fourfold characterised by its theta null point), the Hadamard transform,
//! and theta doubling. It deliberately contains **no isogenies** - those are
//! built on top of this layer in later phases.
//!
//! It mirrors the structure of the dimension-2 theta module in
//! `sqisign-verify` (`crate::theta`), but with 16 coordinates and the
//! dimension-4 formulas, and it reuses the existing `Fp2` field arithmetic.
//!
//! # Projective coordinates (read this first)
//!
//! A theta point - and in particular a theta **null** point - is defined only
//! up to a common non-zero scalar: `(λ·P₀ : … : λ·P₁₅)` and `(P₀ : … : P₁₅)`
//! denote the same point. Equality therefore **must** cross-multiply against a
//! pivot ([`ThetaPointDim4::projective_eq`]); comparing coordinates directly is
//! a bug. This is the single most important correctness fact ported from the
//! Phase 0 oracle.
//!
//! # Index convention
//!
//! The 16 coordinates are indexed by a 4-bit value
//! `k = i₀ + 2·i₁ + 4·i₂ + 8·i₃`, matching the sage `Theta_dim4` reference
//! (`multindex_to_index`).
//!
//! # Reference
//!
//! Ported from the `Theta_dim4` sage package by Pierrick Dartois
//! (<https://github.com/Pierrick-Dartois/Theta_dim4>), specifically
//! `theta_structures/Theta_dim4.py` and `theta_structures/theta_helpers_dim4.py`.
//!
//! # Module organization
//!
//! This module was previously the standalone `theta4` crate; it now lives
//! inside `sqisign-verify` as the dimension-4 counterpart to the dim-2
//! [`crate::theta`] module. It reuses the crate's `Fp`/`Fp2`/`ec` primitives
//! directly (`crate::…`). The optimal-strategy chain loop ([`strategy`]) keeps a
//! small, data-dependent stack of intermediate kernel bases (bounded by the
//! chain length, ~67 at Level 1) in heap `Vec`s - the only `alloc` use, and off
//! the constant-time path (verification orchestration, not field arithmetic).

// The layer is documented at module level; its internals are the round-2
// port's, kept as they were validated.
#![allow(missing_docs, clippy::too_many_arguments)]

pub mod arith;
pub mod basis;
pub mod canonical;
pub mod chain;
pub mod challenge;
pub mod dim2;
pub mod dim4;
pub mod field;
pub mod gluing;
pub mod gluing_chain;
pub mod hd_verify;
pub mod isogeny;
pub mod kani;
mod nqr_tables_p324_3;
pub mod params;
pub mod point;
pub mod primality;
pub mod product_theta;
pub mod profile;
pub mod response;
pub mod self_contained;
pub mod strategy;
pub mod structure;
pub mod two_point;
pub mod uint;
pub mod wire;

pub use arith::{
    act_point, hadamard, hadamard_assign, pointwise_mul_assign, pointwise_square,
    pointwise_square_assign, to_squared_theta, to_squared_theta_assign,
};
pub use basis::{canonical_hints, hd_torsion_basis, jac_to_affine, torsion_basis_2f_from_hint};
pub use canonical::make_canonical;
pub use chain::{middle_codomain_matches, run_half_chain, run_half_chain_collect};
pub use challenge::{recover_challenge, recover_challenge_prof, ChallengeRecovery};
pub use dim2::{
    apply_mat4, base_change_theta_dim2, hadamard2, squared_theta2, GluingThetaIsogenyDim2,
    IsogenyChainDim2, ThetaIsogenyDim2, ThetaStructureDim2, TuplePoint,
};
pub use dim4::{apply_base_change_theta_dim4, base_change_theta_dim4, BaseChangeDim4};
pub use gluing::{GluingIsogenyDim4, GLUING_KERNEL_DIRS};
pub use gluing_chain::{
    jac_mul_u128, point_matrix_product_k, point_matrix_product_k_fixed, FixedBase,
    KaniGluingChainHalf, TuplePoint4,
};
pub use hd_verify::{
    hd_challenge, hd_challenge_len, recover_response_cd, HdReject, MAX_CHAL_BYTES,
};
pub use isogeny::IsogenyDim4;
pub use kani::{
    complete_symplectic_dim4, gluing_bc_dim4_f1, gluing_bc_dim4_f2, gluing_dim2_f1, gluing_dim2_f2,
    inverse_mod_pow2, is_symplectic_dim4, kernel_matrix_f1, kernel_matrix_f2_dual, matrix_f,
    matrix_f_dual, norm_equation_2f_minus_q, starting_two_symplectic_matrices, sum_of_two_squares,
};
pub use params::{pk_wire_bytes, sig_wire_bytes, HdLevel, MAX_PK_WIRE_BYTES, MAX_SIG_WIRE_BYTES};
pub use point::{ThetaPointDim4, THETA_DIM4_N};
pub use product_theta::{
    product_null_dim2, product_theta_dim2, product_theta_dim2to4, ThetaStructureDim1,
};
pub use profile::{
    CycleProfiler, NoProfiler, ProfileRecord, Profiler, SLOTS, SLOT_NAMES, SUB_NAMES, SUB_SLOTS,
};
pub use response::{recover_response, recover_response_prof, ResponseRecovery, ResponseScalars};
pub use self_contained::{
    hd_codomains, hd_image, hd_kernel_setup, hd_verify, hd_verify_bool, hd_verify_profiled,
    hd_verify_profiled_full, hd_verify_profiled_record, hd_verify_with, HdCodomains, HdKernelSetup,
    HdSignature, HdVerifyOptions, HdVerifyReport, KernelPoints,
};
pub use strategy::{
    optimised_strategy, run_strategy_chain, run_strategy_chain_prof, StrategyChain,
};
pub use structure::ThetaStructureDim4;
pub use two_point::{
    gluing_images_paired, null_fixed_by_pi, permute_pi, run_strategy_chain_two_point,
    run_strategy_chain_two_point_checked, PI, PI_FIXED, PI_PAIRS,
};
pub use uint::U4;
pub use wire::{
    challenge_limbs, encode_public_key, encode_signature, hd_verify_bytes, hd_verify_bytes_with,
    hd_verify_parsed, hd_verify_parsed_with, parse_public_key, parse_signature, public_key_bytes,
    signature_bytes, ParsedPublicKey, ParsedSignature,
};
